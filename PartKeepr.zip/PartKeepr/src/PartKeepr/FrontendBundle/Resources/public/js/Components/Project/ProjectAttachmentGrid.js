Ext.define('PartKeepr.ProjectAttachmentGrid', {
    extend: 'PartKeepr.AttachmentGrid',
    alias: 'widget.ProjectAttachmentGrid',

    model: "PartKeepr.ProjectBundle.Entity.ProjectAttachment"
});
