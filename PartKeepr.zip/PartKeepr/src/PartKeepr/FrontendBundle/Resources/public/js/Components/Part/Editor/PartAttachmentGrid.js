Ext.define('PartKeepr.PartAttachmentGrid', {
	extend: 'PartKeepr.AttachmentGrid',
	alias: 'widget.PartAttachmentGrid',
	
	model: "PartKeepr.PartBundle.Entity.PartAttachment"
});