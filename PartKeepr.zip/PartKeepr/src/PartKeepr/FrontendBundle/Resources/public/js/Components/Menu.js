Ext.define('PartKeepr.Menu', {
	extend: 'Ext.toolbar.Toolbar',
	items: [{
		
	}]
});