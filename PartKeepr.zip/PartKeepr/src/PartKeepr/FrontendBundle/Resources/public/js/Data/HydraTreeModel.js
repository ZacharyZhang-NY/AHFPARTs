Ext.define("PartKeepr.data.HydraTreeModel", {
    extend: 'Ext.data.TreeModel',

    mixins: ['PartKeepr.data.CallActions']
});
