Ext.define('PartKeepr.FootprintAttachmentGrid', {
    extend: 'PartKeepr.AttachmentGrid',
    alias: 'widget.FootprintAttachmentGrid',

    model: "PartKeepr.FootprintBundle.Entity.FootprintAttachment"
});
