<?php

namespace PartKeepr\FrontendBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PartKeeprFrontendBundle extends Bundle
{
}
