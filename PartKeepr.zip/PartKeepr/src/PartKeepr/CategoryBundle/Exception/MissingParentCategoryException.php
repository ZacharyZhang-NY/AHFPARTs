<?php

namespace PartKeepr\CategoryBundle\Exception;

class MissingParentCategoryException extends \Exception
{
}
