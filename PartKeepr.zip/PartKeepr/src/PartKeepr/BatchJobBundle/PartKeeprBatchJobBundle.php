<?php

namespace PartKeepr\BatchJobBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PartKeeprBatchJobBundle extends Bundle
{
}
