<?php

namespace PartKeepr\CronLoggerBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PartKeeprCronLoggerBundle extends Bundle
{
}
