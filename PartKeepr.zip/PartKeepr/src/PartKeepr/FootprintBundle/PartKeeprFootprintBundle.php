<?php

namespace PartKeepr\FootprintBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PartKeeprFootprintBundle extends Bundle
{
}
