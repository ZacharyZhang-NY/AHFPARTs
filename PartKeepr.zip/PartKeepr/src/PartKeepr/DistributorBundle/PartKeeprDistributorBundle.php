<?php

namespace PartKeepr\DistributorBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PartKeeprDistributorBundle extends Bundle
{
}
