---
name: Help request
about: Request help from the developers or ask for another reason
labels: help-requested, needs-triage
title: ''
assignees: ''

---

[comment]: # (Please be as specific as possible)

[comment]: # (Please note that there are other channels for custom questions that might be better suited. See https://partkeepr.org/support/. There is a high chance your issue will simply be rejected and closed here. Consider looking on the community channels.)
