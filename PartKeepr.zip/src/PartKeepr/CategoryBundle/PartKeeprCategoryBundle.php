<?php

namespace PartKeepr\CategoryBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PartKeeprCategoryBundle extends Bundle
{
}
