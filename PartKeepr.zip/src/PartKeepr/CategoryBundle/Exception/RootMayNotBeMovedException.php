<?php

namespace PartKeepr\CategoryBundle\Exception;

class RootMayNotBeMovedException extends \Exception
{
}
