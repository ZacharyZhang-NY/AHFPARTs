//@todo remove with ExtJS 6.2.1
Ext.define('Ext.overrides.form.field.Checkbox', {
    override : 'Ext.form.field.Checkbox',

    uncheckedValue : false
});
