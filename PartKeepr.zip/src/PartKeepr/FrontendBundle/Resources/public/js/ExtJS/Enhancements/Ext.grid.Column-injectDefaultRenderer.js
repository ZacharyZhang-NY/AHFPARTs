Ext.override(Ext.grid.column.Column, {
	defaultRenderer: Ext.util.Format.htmlEncode
});