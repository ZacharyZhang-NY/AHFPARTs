/**
 * Returns an internationalized string.
 * @param string
 * @return {*}
 */
function i18n (string) {
	return string;
}