Ext.define("PartKeepr.Data.ReflectionFieldTreeModel", {
    extend: "Ext.data.TreeModel",

    fields: [{
        name: "entityIndex",
        type: 'int'
    }]
});
