Ext.define("PartKeepr.Actions.BaseAction", {
   execute: function () {}
});
