Ext.define("PartKeepr.Models.ColumnRendererConfiguration", {
    extend: "Ext.data.Model",
    fields: [
        {name: 'rtype', type: 'string'},
        {name: 'config', type: 'string'}
    ]
});
