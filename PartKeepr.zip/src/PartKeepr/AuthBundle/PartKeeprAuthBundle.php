<?php

namespace PartKeepr\AuthBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PartKeeprAuthBundle extends Bundle
{
}
