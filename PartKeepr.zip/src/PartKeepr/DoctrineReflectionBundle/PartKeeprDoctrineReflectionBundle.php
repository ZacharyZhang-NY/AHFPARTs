<?php

namespace PartKeepr\DoctrineReflectionBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PartKeeprDoctrineReflectionBundle extends Bundle
{
}
