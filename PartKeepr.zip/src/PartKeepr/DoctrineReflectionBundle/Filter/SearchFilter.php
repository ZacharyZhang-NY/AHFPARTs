<?php

namespace PartKeepr\DoctrineReflectionBundle\Filter;

class SearchFilter
{
}
