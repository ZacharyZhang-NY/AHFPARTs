# PHP 5.6

Several distributions don't have PHP 5.6 yet. Luckily, there are packages for [most distributions](https://wiki.partkeepr.org/wiki/KB00003:PHP_Version).
